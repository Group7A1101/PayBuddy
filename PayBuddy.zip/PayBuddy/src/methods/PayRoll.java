package methods;

import java.util.Scanner;

public class PayRoll {

    public static void main (String[]args){

        int hours;
        double rate;
        double netsalary;
        double grosssalary;
        double philhealth;
        double sss;
        double pagibig;
        double withtax;

        Scanner read = new Scanner(System.in);

        System.out.println("Enter the amount of hours you have worked in a pay period: ");
        hours = read.nextInt();
        System.out.println("Enter your hourly rate: ");
        rate = read.nextDouble();

        grosssalary = rate * hours;
        philhealth = (grosssalary * 0.03)*0.5;
        sss = 0;
        if(grosssalary < 3250) {
            sss = 135;
        } else if (grosssalary <= 3750) {
            sss = 157.50;
        } else if (grosssalary <= 4250) {
            sss = 180;
        } else if (grosssalary <= 4750) {
            sss = 202.50;
        } else if (grosssalary <= 5250) {
            sss = 225;
        } else if (grosssalary <= 5750) {
            sss = 247.50;
        } else if (grosssalary <= 6250) {
            sss = 270;
        } else if (grosssalary <= 6750) {
            sss = 292.50;
        } else if (grosssalary <= 7250) {
            sss = 315;
        } else if (grosssalary <= 7750) {
            sss = 337.50;
        } else if (grosssalary <= 8250) {
            sss = 360;
        } else if (grosssalary <= 8750) {
            sss = 382.50;
        } else if (grosssalary <= 9250) {
            sss = 405;
        } else if (grosssalary <= 9750) {
            sss = 427.50;
        } else if (grosssalary <= 10250) {
            sss = 450;
        } else if (grosssalary <= 10750) {
            sss = 472.50;
        } else if (grosssalary <= 11250) {
            sss = 495;
        } else if (grosssalary <= 11750) {
            sss = 517.50;
        } else if (grosssalary <= 12250) {
            sss = 540;
        } else if (grosssalary <= 12750) {
            sss = 562.50;
        } else if (grosssalary <= 13250) {
            sss = 585;
        } else if (grosssalary <= 13750) {
            sss = 607.50;
        } else if (grosssalary <= 14250) {
            sss = 630;
        } else if (grosssalary <= 14750) {
            sss = 652.50;
        } else if (grosssalary <= 15250) {
            sss = 675;
        } else if (grosssalary <= 15750) {
            sss = 697.50;
        } else if (grosssalary <= 16250) {
            sss = 720;
        } else if (grosssalary <= 16750) {
            sss = 742.50;
        } else if (grosssalary <= 17250) {
            sss = 765;
        } else if (grosssalary <= 17750) {
            sss = 787.50;
        } else if (grosssalary <= 18250) {
            sss = 810;
        } else if (grosssalary <= 18750) {
            sss = 832.50;
        } else if (grosssalary <= 19250) {
            sss = 855;
        } else if (grosssalary <= 19750) {
            sss = 877.50;
        } else if (grosssalary <= 20250) {
            sss = 900;
        } else if (grosssalary <= 20750) {
            sss = 922.50;
        } else if (grosssalary <= 21250) {
            sss = 945;
        } else if (grosssalary <= 21750) {
            sss = 967.50;
        } else if (grosssalary <= 22250) {
            sss = 990;
        } else if (grosssalary <= 22750) {
            sss = 1012.50;
        } else if (grosssalary <= 23250) {
            sss = 1035;
        } else if (grosssalary <= 23750) {
            sss = 1057.50;
        } else if (grosssalary <= 24250) {
            sss = 1080;
        } else if (grosssalary <= 24750) {
            sss = 1102.50;
        } else if (grosssalary > 24750) {
            sss = 1125;
        }
        pagibig = 0;
        if(grosssalary < 1500){
            pagibig = grosssalary * 0.01;
        } else if (grosssalary > 1500) {
            pagibig = grosssalary * 0.02;
        }

        withtax = 0;
        if (grosssalary <= 20832){
            System.out.println("No Withholding Tax");
        } else if (grosssalary < 33333) {
            withtax = (grosssalary - 20833)*0.2;
        } else if (grosssalary < 66667) {
            withtax = (grosssalary - 35833)*0.25;
        } else if (grosssalary < 166667) {
            withtax = (grosssalary - 77500)*0.3;
        } else if (grosssalary < 666667) {
            withtax = (grosssalary - 207500.33) * 0.32;
        } else if (grosssalary > 666667) {
            withtax = (grosssalary - 867500.33)*0.35;
        }

        netsalary = grosssalary - philhealth - sss - pagibig - withtax;


        System.out.println("Total Hours Worked: " + hours);
        System.out.println("Rate per hour: " + rate);
        System.out.println("Gross Salary: " + grosssalary);
        System.out.println("PhilHealth Contribution (Deduction): " + philhealth);
        System.out.println("Social Security System Contribution (Deduction): " + sss);
        System.out.println("PAG-IBIG Contribution (Deduction): " + pagibig);
        System.out.println("Withholding Tax (Deduction): " + withtax);
        System.out.println("Net Salary: " + netsalary);

    }
}