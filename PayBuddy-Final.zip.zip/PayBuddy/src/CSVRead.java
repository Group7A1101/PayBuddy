import java.io.*;

public class CSVRead {
    public static void main(String[] args) {

        String path = "csv";
        String line = "";

        try {
            BufferedReader br = new BufferedReader(new FileReader(path));

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                System.out.println("Employee Number: " + values[0] + ", First Name: " + values [1]);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

