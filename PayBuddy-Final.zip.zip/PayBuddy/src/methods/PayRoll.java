package methods;
import java.io.*;
import java.util.Scanner;

public class PayRoll {

    public static void main (String[]args){

        int hours;
        double rate;
        double netsalary;
        double grosssalary;
        double philhealth;
        double sss;
        double pagibig;
        double withtax;
        String EmpNum;
        String EmpFirstName;
        String EmpLastName;
        String EmpBirth;
        String EmpAdd;
        String EmpPN;
        String EmpSSS;
        String EmpPH;
        String EmpTIN;
        String EmpPag;
        String EmpStat;
        String EmpPos;
        String EmpImm;
        double EmpBas;
        String EmpRice;
        String EmpPhone;
        String EmpClothing;
        String EmpSemi;
        double EmpHour;

        Scanner read = new Scanner(System.in);

        System.out.println("Enter your Employee Number: ");
        EmpNum = read.next();
        EmpFirstName = " ";
        EmpLastName = " ";
        EmpBirth = " ";
        EmpAdd = " ";
        EmpPN = " ";
        EmpSSS = " ";
        EmpPH = " ";
        EmpTIN = " ";
        EmpPag = " ";
        EmpStat = " ";
        EmpPos = " ";
        EmpImm = " ";
        EmpBas = 0;
        EmpRice = " ";
        EmpPhone = " ";
        EmpClothing = " ";
        EmpSemi = " ";
        EmpHour = 0;
        System.out.println("Enter the amount of hours you have worked in a pay period: ");
        hours = read.nextInt();

        String path = "EmployeeData.csv";
        String line = "";

        try {
            BufferedReader br = new BufferedReader(new FileReader(path));

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if(values[0].equals(EmpNum)){
                    EmpNum = values[0];
                    System.out.println("Employee Number: " + EmpNum);
                    EmpLastName = values[1];
                    System.out.println("Last Name: " + EmpLastName);
                    EmpFirstName = values[2];
                    System.out.println("First Name: " + EmpFirstName);
                    EmpBirth = values[3];
                    System.out.println("Birthdate: " + EmpBirth);
                    EmpAdd = values[4];
                    System.out.println("Address: " + EmpAdd);
                    EmpPN = values[5];
                    System.out.println(("Phone Number: " + EmpPN));
                    EmpSSS = values[6];
                    System.out.println("Social Security Number: " + EmpSSS);
                    EmpPH = values[7];
                    System.out.println("PhilHealth Number: " + EmpPH);
                    EmpTIN = values[8];
                    System.out.println("Tax Identification Number: " + EmpTIN);
                    EmpPag = values[9];
                    System.out.println("PAGIBIG Number: " + EmpPag);
                    EmpStat = values[10];
                    System.out.println("Status: " + EmpStat);
                    EmpPos = values[11];
                    System.out.println("Position: " + EmpPos);
                    EmpImm = values[12];
                    System.out.println("Immediate Supervisor: " + EmpImm);
                    EmpBas = Double.parseDouble(values[13]);
                    System.out.println("Basic Salary: " + EmpBas);
                    EmpRice = values[14];
                    System.out.println("Rice Subsidy: " + EmpRice);
                    EmpPhone = values[15];
                    System.out.println("Phone Allowance: " + EmpPhone);
                    EmpClothing = values[16];
                    System.out.println("Clothing Allowance: " + EmpClothing);
                    EmpSemi = values[17];
                    System.out.println("Gross Semi-Monthly Salary: " + EmpSemi);
                    EmpHour = Double.parseDouble(values[18]);
                    System.out.println("Hourly Rate: " + EmpHour);

                    rate = EmpHour;
                    grosssalary = EmpBas;

                    philhealth = (grosssalary * 0.03)*0.5;
                    System.out.println("PhilHealth Contribution (Deduction): " + philhealth);

                    sss = 0;
                    if(grosssalary < 3250) {
                        sss = 135;
                    } else if (grosssalary <= 3750) {
                        sss = 157.50;
                    } else if (grosssalary <= 4250) {
                        sss = 180;
                    } else if (grosssalary <= 4750) {
                        sss = 202.50;
                    } else if (grosssalary <= 5250) {
                        sss = 225;
                    } else if (grosssalary <= 5750) {
                        sss = 247.50;
                    } else if (grosssalary <= 6250) {
                        sss = 270;
                    } else if (grosssalary <= 6750) {
                        sss = 292.50;
                    } else if (grosssalary <= 7250) {
                        sss = 315;
                    } else if (grosssalary <= 7750) {
                        sss = 337.50;
                    } else if (grosssalary <= 8250) {
                        sss = 360;
                    } else if (grosssalary <= 8750) {
                        sss = 382.50;
                    } else if (grosssalary <= 9250) {
                        sss = 405;
                    } else if (grosssalary <= 9750) {
                        sss = 427.50;
                    } else if (grosssalary <= 10250) {
                        sss = 450;
                    } else if (grosssalary <= 10750) {
                        sss = 472.50;
                    } else if (grosssalary <= 11250) {
                        sss = 495;
                    } else if (grosssalary <= 11750) {
                        sss = 517.50;
                    } else if (grosssalary <= 12250) {
                        sss = 540;
                    } else if (grosssalary <= 12750) {
                        sss = 562.50;
                    } else if (grosssalary <= 13250) {
                        sss = 585;
                    } else if (grosssalary <= 13750) {
                        sss = 607.50;
                    } else if (grosssalary <= 14250) {
                        sss = 630;
                    } else if (grosssalary <= 14750) {
                        sss = 652.50;
                    } else if (grosssalary <= 15250) {
                        sss = 675;
                    } else if (grosssalary <= 15750) {
                        sss = 697.50;
                    } else if (grosssalary <= 16250) {
                        sss = 720;
                    } else if (grosssalary <= 16750) {
                        sss = 742.50;
                    } else if (grosssalary <= 17250) {
                        sss = 765;
                    } else if (grosssalary <= 17750) {
                        sss = 787.50;
                    } else if (grosssalary <= 18250) {
                        sss = 810;
                    } else if (grosssalary <= 18750) {
                        sss = 832.50;
                    } else if (grosssalary <= 19250) {
                        sss = 855;
                    } else if (grosssalary <= 19750) {
                        sss = 877.50;
                    } else if (grosssalary <= 20250) {
                        sss = 900;
                    } else if (grosssalary <= 20750) {
                        sss = 922.50;
                    } else if (grosssalary <= 21250) {
                        sss = 945;
                    } else if (grosssalary <= 21750) {
                        sss = 967.50;
                    } else if (grosssalary <= 22250) {
                        sss = 990;
                    } else if (grosssalary <= 22750) {
                        sss = 1012.50;
                    } else if (grosssalary <= 23250) {
                        sss = 1035;
                    } else if (grosssalary <= 23750) {
                        sss = 1057.50;
                    } else if (grosssalary <= 24250) {
                        sss = 1080;
                    } else if (grosssalary <= 24750) {
                        sss = 1102.50;
                    } else if (grosssalary > 24750) {
                        sss = 1125;
                    }
                    System.out.println("Social Security System Contribution (Deduction): " + sss);

                    pagibig = 0;
                    if(grosssalary < 1500){
                        pagibig = grosssalary * 0.01;
                    } else if (grosssalary > 1500) {
                        pagibig = grosssalary * 0.02;
                    }
                    System.out.println("PAG-IBIG Contribution (Deduction): " + pagibig);

                    withtax = pagibig + sss + philhealth;
                    System.out.println("Withholding Tax (Deduction): " + withtax);

                    System.out.println("Gross Salary: " + grosssalary);

                    netsalary = grosssalary - philhealth - sss - pagibig - withtax;
                    System.out.println("Net Salary: " + netsalary);
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
